512bytes.exe - creepy project

respect for 000.exe
any damage to your computer caused by this software is at your own risk and the author will not be held responsible.
i also recommend that you run this software on a virtual machine.
support OS: Windows 8, Windows 8.1, Windows 10, Windows 11

このソフトによるコンピューターへのダメージは全て自己責任となり、作者は責任を取りません。
また、バーチャルマシン上での実行を推奨します
対応OS: Windows8, Windows8.1, Windows10, Windows 11

coded by nk